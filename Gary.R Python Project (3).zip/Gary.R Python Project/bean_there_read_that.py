# ---------------------------------------------------------
# Bean There, Read That – Simple Order Application
# ---------------------------------------------------------
# This program allows customers to:
# - View products
# - View product details
# - Add items to an order
# - Review their order
# - Employees can apply a 10% staff discount
# - Save the final order as a TXT file
# ---------------------------------------------------------

# -----------------------------
# PRODUCT LIST
# -----------------------------
# A list of dictionaries. Each dictionary represents a product.
products = [
    {"id": "1", "name": "Espresso", "price": 2.50, "details": "Strong and bold single shot."},
    {"id": "2", "name": "Cappuccino", "price": 3.20, "details": "Foamy and smooth classic coffee."},
    {"id": "3", "name": "Latte", "price": 3.50, "details": "Milky and sweet coffee drink."},
    {"id": "4", "name": "Hot Chocolate", "price": 3.00, "details": "Rich chocolate drink."},
    {"id": "5", "name": "Hackney Butcher (Book)", "price": 12.99, "details": "Crime thriller set in Hackney."},
    {"id": "6", "name": "Jigsaw Man (Book)", "price": 18.50, "details": "Dark detective mystery novel."}
]

# -----------------------------
# ORDER STORAGE
# -----------------------------
# This list will store the products the customer chooses.
order = []


# -----------------------------
# MAIN MENU DISPLAY
# -----------------------------
def show_menu():
    print("\n--- Bean There, Read That Menu ---")
    print("1. View products")
    print("2. View product details")
    print("3. Add product to order")
    print("4. Review order")
    print("5. Apply staff discount")
    print("6. Save order to TXT")
    print("7. Exit")


# -----------------------------
# SHOW ALL PRODUCTS
# -----------------------------
def show_products():
    print("\n--- Products ---")
    for p in products:
        print(f"{p['id']}. {p['name']} (€{p['price']})")


# -----------------------------
# SHOW PRODUCT DETAILS
# -----------------------------
def show_details():
    pid = input("Enter product ID to view details: ")
    for p in products:
        if p["id"] == pid:
            print(f"\n{p['name']}")
            print(f"Price: €{p['price']}")
            print(f"Details: {p['details']}")
            return
    print("Product not found.")


# -----------------------------
# ADD PRODUCT TO ORDER
# -----------------------------
def add_to_order():
    pid = input("Enter product ID to add: ")
    for p in products:
        if p["id"] == pid:
            order.append(p)
            print(f"Added: {p['name']}")
            return
    print("Invalid product ID.")


# -----------------------------
# REVIEW ORDER
# -----------------------------
def review_order():
    print("\n--- Your Order ---")
    if not order:
        print("Your order is empty.")
        return

    total = sum(item["price"] for item in order)

    for item in order:
        print(f"{item['name']} - €{item['price']}")

    print(f"Total: €{total:.2f}")


# -----------------------------
# APPLY STAFF DISCOUNT (10%)
# -----------------------------
def apply_staff_discount():
    if not order:
        print("Order is empty.")
        return

    total = sum(item["price"] for item in order)
    discount = total * 0.10
    final_total = total - discount

    print("\nStaff discount applied (10% off).")
    print(f"Original total: €{total:.2f}")
    print(f"Discount: €{discount:.2f}")
    print(f"Final total: €{final_total:.2f}")


# -----------------------------
# SAVE ORDER TO TXT FILE
# -----------------------------
# Writes each item and the total into a plain text file.
def save_order_txt():
    if not order:
        print("Cannot save an empty order.")
        return

    total = sum(item["price"] for item in order)

    try:
        with open("order.txt", "w") as f:
            f.write("----- Bean There, Read That Order -----\n\n")
            for item in order:
                f.write(f"{item['name']} - €{item['price']}\n")
            f.write(f"\nTotal: €{total:.2f}\n")

        print("Order saved to order.txt")
    except Exception:
        print("Could not save order.")


# ---------------------------------------------------------
# MAIN PROGRAM LOOP
# ---------------------------------------------------------
while True:
    show_menu()
    choice = input("\nChoose an option: ")

    if choice == "1":
        show_products()
    elif choice == "2":
        show_details()
    elif choice == "3":
        add_to_order()
    elif choice == "4":
        review_order()
    elif choice == "5":
        apply_staff_discount()
    elif choice == "6":
        save_order_txt()
    elif choice == "7":
        print("Thanks for visiting Bean There, Read That!")
        break
    else:
        print("Invalid choice.")
